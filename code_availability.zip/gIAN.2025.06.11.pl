#!/usr/bin/perl -w  

system("nvcc -I /usr/include/cuda/ -L /usr/lib64/ --cudart=shared -Wno-deprecated-gpu-targets -lcufft IAN.CUDA.2025.06.11.cu -o IAN.CUDA.2025.06.11.out");

$random     = 1;
$checkpoint = 1;

$outputQ     = 1;
$outputW     = 1;
$outputV     = 1;

$outputK     = 0;
$outputP     = 0;
$outputT     = 1;
$outputD     = 0;

$outputH     = 1;
$outputU     = 1;
$outputTE   = 1;

$OPres      = 1000;
$MCres      = 100000000;
$bins       = 1000;

$T          = 10000;
$L          = 512;
$dx         = 0.1;
$dt         = 0.00001;

$hydro      = 1;
$nMGlayers  = 5;
$nMGsteps   = 5;
$nSmooth    = 20;

$stokes = 1;
$use_FFT = 1;

$lambda    = 0;
$gamm      = 1;
$K         = 1;
$L3        = 0;
$A         = 100;
$alpha     = -32.5;
$mu        = 0;
$eta       = 0.25;


open (FILE, '>input.AN.2025.06.11.dat');  #simulation parameters

print FILE "$random\n";
print FILE "$checkpoint\n";

print FILE "$outputQ\n";
print FILE "$outputW\n";
print FILE "$outputV\n";

print FILE "$outputK\n";
print FILE "$outputP\n";
print FILE "$outputT\n";
print FILE "$outputD\n";

print FILE "$outputH\n";
print FILE "$outputU\n";
print FILE "$outputTE\n";

print FILE "$OPres\n";
print FILE "$MCres\n";
print FILE "$bins\n";

print FILE "$T\n";
print FILE "$L\n";
print FILE "$dx\n";
print FILE "$dt\n";

print FILE "$hydro\n";
print FILE "$nMGlayers\n";
print FILE "$nMGsteps\n";
print FILE "$nSmooth\n";

print FILE "$stokes\n";
print FILE "$use_FFT\n";

print FILE "$lambda\n";
print FILE "$gamm\n";   
print FILE "$K\n";
print FILE "$L3\n";
print FILE "$A\n";
print FILE "$alpha\n";
print FILE "$mu\n";
print FILE "$eta\n";

close (FILE);

system("./IAN.CUDA.2025.06.11.out >Prints.dat");
system("cat Prints.dat");

system("python3 FieldPlotter.py");
