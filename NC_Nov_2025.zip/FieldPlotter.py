#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.animation as animation

plotTheta = 0
plotS     = 0
plotSch   = 0
plotW     = 1

ims = []
path = ''

qxxfname = path+'an_qxx.txt'
qxyfname = path+'an_qxy.txt'
wfname = path+'an_w.txt'

if (plotTheta+plotS+plotSch < 2)&(plotTheta+plotS+plotSch > 0)&(plotW < 1):
    qxxT = np.loadtxt(qxxfname);
    qxyT = np.loadtxt(qxyfname);
    [m,n] = qxxT.shape
    
    if (m == n):
        startt = 0
        endt   = 1
    else:
        T = int(m/n);
        startt = 0
        endt   = T
 
    for t in range(startt,endt):
    
        qxx = qxxT[t*n:(t+1)*n,:]
        qxy = qxyT[t*n:(t+1)*n,:]
        qxy[qxy==0] = 0.000000001
        S = 2*np.sqrt(np.multiply(qxx,qxx)+np.multiply(qxy,qxy))
        theta = np.arctan(np.divide(qxy,0.5*S+qxx))
        fig = plt.figure(1)
        
        if (plotTheta > 0):            
            im = plt.imshow(theta, extent=[0, 1, 0, 1], vmin=-np.pi/2, vmax=np.pi/2, animated=True, origin='lower')
            im.set_cmap('hsv')
        if (plotS > 0):
            im = plt.imshow(1-S, extent=[0, 1, 0, 1], vmin=0, vmax= 0.1, animated=True, origin='lower')
            im.set_cmap('Reds')
        if (plotSch > 0):
            Sch = np.abs(np.pi/4-np.mod(theta,np.pi/2));
            im = plt.imshow(Sch, extent=[0, 1, 0, 1], vmin=0, vmax=np.pi/4, animated=True, origin='lower')
            im.set_cmap('gray')
        ims.append([im])


if (plotW > 0)&(plotTheta+plotS+plotSch < 1):
    wT = np.loadtxt(wfname);
    [m,n] = wT.shape
    MW = np.amax(wT)
    mW = np.amin(wT)
    M = np.amax([np.abs(MW),np.abs(mW)])
    if (m == n):
        startt = 0
        endt   = 1
    else:
        T = int(m/n);
        startt = 0
        endt   = T
    for t in range(startt,endt):
        w = wT[t*n:(t+1)*n,:]
        fig = plt.figure(1)
        im = plt.imshow(w, extent=[0, 1, 0, 1], vmin=-M, vmax=M, animated=True, origin='lower')
        im.set_cmap('seismic')
#        plt.colorbar()
        ims.append([im])
 
ani = animation.ArtistAnimation(fig, ims, interval=50,
                                repeat_delay=500)


plt.show()
