#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 10:04:06 2026

@author: d.j.g.pearce
"""

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker


def w_plot(path,figno=127,M=0):
    
    w = np.loadtxt(path+'T_w.txt')
    [m,n] = np.shape(w)

    if (M==0):
        M = np.max([np.abs(np.max(w)),np.abs(np.min(w))])
    plt.figure(figno)
    plt.imshow(w,cmap='seismic',vmin=-M,vmax=M)
    plt.xticks([])
    plt.yticks([])

def Q_plot(path,figno=125,smin=0):
    
    qxx = np.loadtxt(path+'T_qxx.txt')
    qxy = np.loadtxt(path+'T_qxy.txt')
    [m,n] = np.shape(qxx)
        
    S = 2*np.sqrt(np.multiply(qxx,qxx)+np.multiply(qxy,qxy));  
    theta = np.arctan(np.divide(qxy,0.5*S+qxx));
    
    plt.figure(figno)
    plt.clf()
    plt.imshow(1-S,cmap='Reds',vmin=0,vmax=1-smin)
    plt.show()
    
    plt.figure(figno+1)
    plt.clf()
    plt.imshow(theta,cmap='hsv',vmin=-np.pi/2,vmax=np.pi/2)
    plt.show()
    

def d_total_energy_transfer_1(path,figno=111,Mx=0,My=0,AR=0.9,my=-909):

    Ds = np.loadtxt(path+'Ds_k.dat.txt')
    Dr = np.loadtxt(path+'Dr_k.dat.txt')
    Di = np.loadtxt(path+'Di_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(Ds[:,0],-Ds[:,1],color = 'blue')
    plt.plot(Dr[:,0],-Dr[:,1],color = 'green')
    plt.plot(Di[:,0],-Di[:,1],color = 'red')
    plt.plot(Ds[:,0],(Ds[:,1]+Dr[:,1]+Di[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(Dr[:,1])),np.max(np.abs(Ds[:,1])),np.max(np.abs(Di[:,1]))])
    if (my==-909):
        my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(AR*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_energy_spectra(path,figno=146,my=0,My=0):
    
    F1 = np.loadtxt(path+'F1_k.dat.txt')
    F2 = np.loadtxt(path+'F2_k.dat.txt')
        
    plt.figure(figno)
    plt.clf()
    plt.plot(F1[:,0],np.log10(F1[:,1]),color = 'blue')
    plt.plot(F2[:,0],np.log10(F2[:,1]),color = 'red')
    ax = plt.gca()

    Mx = 250
    mx = 0
    if (My==0):
        My = -5
    if (my==0):
        my = -13
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    yt = range(my,My+1)
    yl = []
    for i in yt:
        yl = np.append(yl,'$10^{'+str(i)+'}$')
    ax.set_yticks(yt)
#    ax.set_yticks(yt,labels=yl)
    ax.set_yticklabels(yl)
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.set_xticks([0,Mx/2,Mx])
    ax.tick_params(axis='both', which='major', labelsize=16)
            

def d_FE_energy_transfer_1(path,figno=113,Mx=0,My=0):
    DH1 = np.loadtxt(path+'Dr_H1_k.dat.txt')
    DH2 = np.loadtxt(path+'Dr_H2_k.dat.txt')
    DH1H2= np.loadtxt(path+'Dr_H1H2_k.dat.txt')
    De = np.loadtxt(path+'De_k.dat.txt')
    Df = np.loadtxt(path+'Df_k.dat.txt')
    Dt = np.loadtxt(path+'Dt_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(De[:,0],De[:,1],color = 'green')
    plt.plot(Dt[:,0],Dt[:,1],color = 'pink')
    plt.plot(De[:,0],-Df[:,1],color = 'brown')
    plt.plot(De[:,0],-DH1[:,1],color = 'blue')
    plt.plot(De[:,0],-DH2[:,1],color = 'orange')
    plt.plot(De[:,0],-DH1H2[:,1],color = 'red')
    plt.plot(De[:,0],-(De[:,1]-DH1[:,1]-DH2[:,1]-DH1H2[:,1]-Df[:,1]+Dt[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(De[:,1])),np.max(np.abs(Df[:,1])),np.max(np.abs(DH1[:,1])),np.max(np.abs(DH2[:,1])),np.max(np.abs(DH1H2[:,1]))])
    my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)
    
def d_FE_over_time(path,midX=0,pathO='n',my=-99,My=0,mx=-1,Mx=-1,figno=202,file_pref=''):
    E = np.loadtxt(path+'FEnergy_t.dat.txt')    
    plt.figure(figno)
    plt.clf()
    
    if (mx == -1):
        if (midX == 0):
            mx = 0
        else:
            mx=-midX
    if (Mx == -1):
        if (midX == 0):
            Mx = E[-1,0]
        else:
            Mx=midX
    if (my == -99):
        my = np.min(E[:,1])
    if (My == 0):
        My = np.max(E[:,1])+np.max(E[:,2])
        
    plt.plot((E[:,0]-midX),E[:,1],color='blue')
    plt.plot((E[:,0]-midX),E[:,2],color='red')
    plt.plot((E[:,0]-midX),E[:,1]+E[:,2],color='black')
    
    ax = plt.gca()
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_yticks([my,(my+My)/2,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_KE_energy_transfer_1(path,figno=112,Mx=0,My=0):

    Ds = np.loadtxt(path+'Ds_k.dat.txt')
    Di = np.loadtxt(path+'Di_k.dat.txt')
    Dt = np.loadtxt(path+'Dt_k.dat.txt')
    De = np.loadtxt(path+'De_k.dat.txt')
    Df = np.loadtxt(path+'Df_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(Ds[:,0],-Ds[:,1],color = 'blue')
    plt.plot(De[:,0],-De[:,1],color = 'green')
    plt.plot(Di[:,0],-Di[:,1],color = 'red')
    plt.plot(Dt[:,0],-Dt[:,1],color = 'pink')
    plt.plot(Dt[:,0],+Df[:,1],color = 'brown')
    plt.plot(Dt[:,0],-(Ds[:,1]+De[:,1]+Di[:,1]+Dt[:,1]-Df[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(De[:,1])),np.max(np.abs(Ds[:,1])),np.max(np.abs(Di[:,1])),np.max(np.abs(Dt[:,1])),np.max(np.abs(Df[:,1]))])
    my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_KE_spectra(path,figno=146,mx=0,Mx=2,my=-99,My=99):
    
    F1 = np.loadtxt(path+'KE_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(np.log10(F1[:,0]),np.log10(F1[:,1]),color = 'green')
    ax = plt.gca()
        
    if (my==-99):
        my = -6
    if (My == 99):
        My = 1
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    yt = range(my,My+1)
    yl = []
    for i in yt:
        yl = np.append(yl,'$10^{'+str(i)+'}$')
    ax.set_yticks(yt)
    ax.set_yticklabels(yl)
    xt = range(mx,Mx+1)
    xl = []
    for i in xt:
        xl = np.append(xl,'$10^{'+str(i)+'}$')
    ax.set_xticks(xt)
    ax.set_xticklabels(xl)
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.set_xticks([0,Mx/2,Mx])
    ax.tick_params(axis='both', which='major', labelsize=16)


def make_figS1():
    
    path = 'S1/a/'
    d_KE_energy_transfer_1(path,Mx=80,My=0.015,figno=10100)
    path = 'S1/b/'
    d_KE_energy_transfer_1(path,Mx=160,My=0.003,figno=10101)
    

def make_figS2(figno=10200):
    
    F1M = np.loadtxt('S2/kFmax.txt')
    lF1M = np.loadtxt('S2/lkFmax.txt')
    F1E = np.loadtxt('S2/kF0.txt')
            
    F2M = np.loadtxt('S2/kLmax.txt')
    lF2M = np.loadtxt('S2/lkLmax.txt')
    F2E = np.loadtxt('S2/kL0.txt')
            
    plt.figure(figno)
    plt.imshow(F1M,origin='lower',cmap='PuBuGn')
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    plt.figure(figno+1)
    plt.imshow(F1E,origin='lower',cmap='PuBuGn',vmin=10,vmax=60)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    plt.figure(figno+2)
    plt.imshow(F2M,origin='lower',cmap='PuBuGn',vmin=8,vmax=50)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    plt.figure(figno+3)
    plt.imshow(F2E,origin='lower',cmap='PuBuGn',vmin=7,vmax=150)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')


    plt.figure(figno+4)
    plt.imshow(lF1M,origin='lower',cmap='seismic',vmin=0.05,vmax=0.15)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    plt.figure(figno+5)
    plt.imshow(lF2M,origin='lower',cmap='seismic',vmin=0.05,vmax=0.15)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

def make_figS3():
    
    path = 'S3/a/'
    d_KE_spectra(path,my=-5,My=0,figno=10300)
    path = 'S3/b/'
    d_KE_spectra(path,my=-6,My=-2,figno=10301)

def make_figS4():
    

    path = 'S4/l_0.5/'
    d_total_energy_transfer_1(path,Mx=40,My=0.03,figno=10400)
    d_KE_energy_transfer_1(path,Mx=40,My=0.03,figno=10401)
    d_FE_energy_transfer_1(path,Mx=160,My=0.0075,figno=10402)
    Q_plot(path,figno=10403)
    w_plot(path,figno=10405)

    path = 'S4/l_-0.5/'
    d_total_energy_transfer_1(path,Mx=80,My=0.0075,figno=10406)
    d_KE_energy_transfer_1(path,Mx=80,My=0.0075,figno=10407)
    d_FE_energy_transfer_1(path,Mx=160,My=0.0017,figno=10408)
    Q_plot(path,figno=10409)
    w_plot(path,figno=10411)

def make_figS5():
    path = 'S5/'
    
    plt.figure(10500)
    St = np.loadtxt(path+'The_S.txt')
    plt.imshow(1-St,cmap='Reds',vmin=0,vmax=1)

    plt.figure(10501)
    Se = np.loadtxt(path+'Exp_S.txt')
    plt.imshow(1-Se,cmap='Reds',vmin=0,vmax=1)

    plt.figure(10502)
    Te = np.loadtxt(path+'Exp_theta.txt')
    plt.imshow(Te,cmap='hsv',vmin=-np.pi/2,vmax=np.pi/2)


    M = np.loadtxt(path+'Exp_eps_pred.dat')
    plt.figure(10506)
    plt.clf()
    plt.plot(M[:,0],M[:,1])
    plt.fill_between(M[:,0], M[:,1]-M[:,2], M[:,1]+M[:,2],alpha=0.5)
    ax=plt.gca()
    ax.set_xlim([1,1.5])
    ax.set_xticks([1,1.25,1.5])
    ax.set_ylim([0,0.03])
    ax.set_yticks([0,0.015,0.03])


def make_figS6():
    

    path = 'S6/'
    d_total_energy_transfer_1(path,Mx=40,My=0.02,figno=10600)
    d_KE_energy_transfer_1(path,Mx=40,My=0.02,figno=10601)
    d_FE_energy_transfer_1(path,Mx=160,My=0.0009,figno=10602)
    Q_plot(path,figno=10603)
    w_plot(path,figno=10605)





make_figS1()
make_figS2()
make_figS3()
make_figS4()
make_figS5()
make_figS6()




























