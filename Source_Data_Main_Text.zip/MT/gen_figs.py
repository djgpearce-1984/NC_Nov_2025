#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar  9 10:04:06 2026

@author: d.j.g.pearce
"""

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.ticker as ticker


def w_plot(path,figno=127,M=0):
    
    w = np.loadtxt(path+'T_w.txt')
    [m,n] = np.shape(w)

    if (M==0):
        M = np.max([np.abs(np.max(w)),np.abs(np.min(w))])
    plt.figure(figno)
    plt.imshow(w,cmap='seismic',vmin=-M,vmax=M)
    plt.xticks([])
    plt.yticks([])

def Q_plot(path,figno=125,smin=0):
    
    qxx = np.loadtxt(path+'T_qxx.txt')
    qxy = np.loadtxt(path+'T_qxy.txt')
    [m,n] = np.shape(qxx)
        
    S = 2*np.sqrt(np.multiply(qxx,qxx)+np.multiply(qxy,qxy));  
    theta = np.arctan(np.divide(qxy,0.5*S+qxx));
    
    plt.figure(figno)
    plt.clf()
    plt.imshow(1-S,cmap='Reds',vmin=0,vmax=1-smin)
    plt.show()
    
    plt.figure(figno+1)
    plt.clf()
    plt.imshow(theta,cmap='hsv',vmin=-np.pi/2,vmax=np.pi/2)
    plt.show()
    

def d_total_energy_transfer_1(path,figno=111,Mx=0,My=0,AR=0.9,my=-909):

    Ds = np.loadtxt(path+'Ds_k.dat.txt')
    Dr = np.loadtxt(path+'Dr_k.dat.txt')
    Di = np.loadtxt(path+'Di_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(Ds[:,0],-Ds[:,1],color = 'blue')
    plt.plot(Dr[:,0],-Dr[:,1],color = 'green')
    plt.plot(Di[:,0],-Di[:,1],color = 'red')
    plt.plot(Ds[:,0],(Ds[:,1]+Dr[:,1]+Di[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(Dr[:,1])),np.max(np.abs(Ds[:,1])),np.max(np.abs(Di[:,1]))])
    if (my==-909):
        my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(AR*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_energy_spectra(path,figno=146,my=0,My=0):
    
    F1 = np.loadtxt(path+'F1_k.dat.txt')
    F2 = np.loadtxt(path+'F2_k.dat.txt')
        
    plt.figure(figno)
    plt.clf()
    plt.plot(F1[:,0],np.log10(F1[:,1]),color = 'blue')
    plt.plot(F2[:,0],np.log10(F2[:,1]),color = 'red')
    ax = plt.gca()

    Mx = 250
    mx = 0
    if (My==0):
        My = -5
    if (my==0):
        my = -13
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    yt = range(my,My+1)
    yl = []
    for i in yt:
        yl = np.append(yl,'$10^{'+str(i)+'}$')
    ax.set_yticks(yt)
#    ax.set_yticks(yt,labels=yl)
    ax.set_yticklabels(yl)
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.set_xticks([0,Mx/2,Mx])
    ax.tick_params(axis='both', which='major', labelsize=16)
            

def d_FE_energy_transfer_1(path,figno=113,Mx=0,My=0):
    DH1 = np.loadtxt(path+'Dr_H1_k.dat.txt')
    DH2 = np.loadtxt(path+'Dr_H2_k.dat.txt')
    DH1H2= np.loadtxt(path+'Dr_H1H2_k.dat.txt')
    De = np.loadtxt(path+'De_k.dat.txt')
    Df = np.loadtxt(path+'Df_k.dat.txt')
    Dt = np.loadtxt(path+'Dt_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(De[:,0],De[:,1],color = 'green')
    plt.plot(Dt[:,0],Dt[:,1],color = 'pink')
    plt.plot(De[:,0],-Df[:,1],color = 'brown')
    plt.plot(De[:,0],-DH1[:,1],color = 'blue')
    plt.plot(De[:,0],-DH2[:,1],color = 'orange')
    plt.plot(De[:,0],-DH1H2[:,1],color = 'red')
    plt.plot(De[:,0],-(De[:,1]-DH1[:,1]-DH2[:,1]-DH1H2[:,1]-Df[:,1]+Dt[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(De[:,1])),np.max(np.abs(Df[:,1])),np.max(np.abs(DH1[:,1])),np.max(np.abs(DH2[:,1])),np.max(np.abs(DH1H2[:,1]))])
    my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)
    
def d_FE_over_time(path,midX=0,pathO='n',my=-99,My=0,mx=-1,Mx=-1,figno=202,file_pref=''):
    E = np.loadtxt(path+'FEnergy_t.dat.txt')    
    plt.figure(figno)
    plt.clf()
    
    if (mx == -1):
        if (midX == 0):
            mx = 0
        else:
            mx=-midX
    if (Mx == -1):
        if (midX == 0):
            Mx = E[-1,0]
        else:
            Mx=midX
    if (my == -99):
        my = np.min(E[:,1])
    if (My == 0):
        My = np.max(E[:,1])+np.max(E[:,2])
        
    plt.plot((E[:,0]-midX),E[:,1],color='blue')
    plt.plot((E[:,0]-midX),E[:,2],color='red')
    plt.plot((E[:,0]-midX),E[:,1]+E[:,2],color='black')
    
    ax = plt.gca()
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_yticks([my,(my+My)/2,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_KE_energy_transfer_1(path,figno=112,Mx=0,My=0):

    Ds = np.loadtxt(path+'Ds_k.dat.txt')
    Di = np.loadtxt(path+'Di_k.dat.txt')
    Dt = np.loadtxt(path+'Dt_k.dat.txt')
    De = np.loadtxt(path+'De_k.dat.txt')
    Df = np.loadtxt(path+'Df_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(Ds[:,0],-Ds[:,1],color = 'blue')
    plt.plot(De[:,0],-De[:,1],color = 'green')
    plt.plot(Di[:,0],-Di[:,1],color = 'red')
    plt.plot(Dt[:,0],-Dt[:,1],color = 'pink')
    plt.plot(Dt[:,0],+Df[:,1],color = 'brown')
    plt.plot(Dt[:,0],-(Ds[:,1]+De[:,1]+Di[:,1]+Dt[:,1]-Df[:,1]),color = 'black',linestyle='dashed')
    ax = plt.gca()
    
    if (Mx==0):
        Mx = 100
    mx = 0
    if (My==0):
        My = 1.1*np.max([np.max(np.abs(De[:,1])),np.max(np.abs(Ds[:,1])),np.max(np.abs(Di[:,1])),np.max(np.abs(Dt[:,1])),np.max(np.abs(Df[:,1]))])
    my = -My
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    ax.set_xticks([mx,Mx/2,Mx])
    ax.set_yticks([my,0,My])
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.tick_params(axis='both', which='major', labelsize=16)

def d_KE_spectra(path,figno=146,mx=0,Mx=2,my=-99,My=99):
    
    F1 = np.loadtxt(path+'KE_k.dat.txt')
    
    
    plt.figure(figno)
    plt.clf()
    plt.plot(np.log10(F1[:,0]),np.log10(F1[:,1]),color = 'green')
    ax = plt.gca()
        
    if (my==-99):
        my = -6
    if (My == 99):
        My = 1
    ax.set_xlim(left = mx, right = Mx)
    ax.set_ylim(bottom = my, top = My)
    yt = range(my,My+1)
    yl = []
    for i in yt:
        yl = np.append(yl,'$10^{'+str(i)+'}$')
    ax.set_yticks(yt)
    ax.set_yticklabels(yl)
    xt = range(mx,Mx+1)
    xl = []
    for i in xt:
        xl = np.append(xl,'$10^{'+str(i)+'}$')
    ax.set_xticks(xt)
    ax.set_xticklabels(xl)
    ax.set_aspect(0.9*(Mx-mx)/(My-my))
    ax.set_xticks([0,Mx/2,Mx])
    ax.tick_params(axis='both', which='major', labelsize=16)


def make_fig1():
    
    path = 'F1/'
    
    Q_plot(path,figno=100)
    w_plot(path,figno=102)
    d_total_energy_transfer_1(path,Mx=80,My=0.02,figno=103)
    d_total_energy_transfer_1(path,Mx=160,My=0.0003,my=-0.0012,AR=1,figno=104)
    d_energy_spectra(path,my=-11,figno=105)
    
def make_fig2():
    path = 'F2/'
    d_FE_energy_transfer_1(path,Mx=160,My=0.0012,figno=200)
    
    d_FE_over_time(path,midX=1.5e-05,my=0.0,My=2.5,mx=-1e-05,Mx=2.5e-5,figno=201)
    Q_plot(path+'T1_',figno=203)
    Q_plot(path+'T2_',figno=205)


def make_fig3(figno=300):

    Ks = np.loadtxt('F3/kstar.txt')    
    plt.figure(figno)
    plt.imshow(Ks,origin='lower',cmap='PuBuGn',vmin=0,vmax=30)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    lKs = np.loadtxt('F3/lkstar.txt')    
    plt.figure(figno+1)
    plt.imshow(lKs,origin='lower',cmap='seismic',vmin=0.025,vmax=0.075)
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

    DrDi = np.loadtxt('F3/DrDi.txt')    
    plt.figure(figno+2)
    plt.imshow(DrDi,origin='lower',vmin = 0.4, vmax=1, cmap='seismic')
    ax = plt.gca()
    ax.set_xticks([0,10,19])
    ax.set_xticklabels([13,79,138])
    ax.set_yticks([0,7,14])
    ax.set_yticklabels([3,30,58])
    ax.tick_params(axis='both', which='major', labelsize=16)
    plt.xlabel('x$10^3$')
    plt.ylabel('x$10^{-4}$')

def make_fig4():
    
    
    path = 'F4/'
    Q_plot(path,figno=400)
    w_plot(path,figno=402)
    
    d_total_energy_transfer_1(path,Mx=160,My=0.003,figno=403)
    d_FE_energy_transfer_1(path,Mx=256,My=0.011,figno=404)
    d_energy_spectra(path,My=-4,my=-9,figno=405)
    
    
    d_FE_over_time(path,midX=1.5e-05,my=0.0,My=5,figno=406,mx=-1.5e-05,Mx=2e-05)
    Q_plot(path+'T1_',figno=407)
    Q_plot(path+'T2_',figno=409)





make_fig1()
make_fig2()
make_fig3()
make_fig4()




























